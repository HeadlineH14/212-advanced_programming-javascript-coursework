"use strict"; // do not modify or delete this line

//Task 1
//data is a string, patterns is an array of patterns
function find(data, patterns) {
	let frequencies={};
	let offsets={};
	
	//your implementation goes here
	
}


//use these for results of analyse1, analyse2 and analyse3
const results1 = {};
const results2 = {};
const results3 = {};

//Task 2
function analyse1(dataFile, patternFile){
	//your implementation goes here
}

//Task 3

const readFilePromise = (filePath) => {
	//your implementation goes here
}

function analyse2(dataFile, patternFile){
	//your implementation goes here
}

//Task 4 

//your implementation for analyse3 goes here



//-------------------------------------------------------------------------------
//do not modify this function
function print(){
	console.log("Printing results...");
	Object.keys(results).forEach(function(elem){
		console.log("sequence: ", elem);
		console.log("frequencies are: ", results[elem].frequencies);
		console.log("offsets are: ", results[elem].offsets);
		console.log("---------------------------");
	});
}
//--------------- export the find function (required for the marking script)
module.exports ={find}; //do not modify this line
